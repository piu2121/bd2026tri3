# bd2026tri3

- é para estar funcionando

pro ts funcionar tem que colar no git bash:  --experimental-transform-types query.ts
e vai retorna as informações

### no ts
JSON Return Object

On success a JSON object will be returned.

{
    "latitude": 52.52,
    "longitude": 13.419,
    "generationtime_ms": 2.2119,
    "timezone": "Europe/Berlin",
    "timezone_abbreviation": "CEST",
    "daily": {
        "time": ["2022-07-01", "2022-07-01", "2022-07-01", ...],
        "temperature_2m_max": [13, 12.7, 12.7, 12.5, 12.5, 12.8, ...]
    },
    "daily_units": {
        "temperature_2m": "°C"
    },
}